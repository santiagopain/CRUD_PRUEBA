<?php
require_once('config.php');

class UserModel {
    private $conn;

    public function __construct() {
        $this->conn = new mysqli(DB_HOST, DB_USER, DB_PASSWORD, DB_NAME);

        if ($this->conn->connect_error) {
            die("Connection failed: " . $this->conn->connect_error);
        }else{


            echo "";

        }
    }

    public function getAllUsers() {
        $query = "SELECT * FROM usuario";
        $result = $this->conn->query($query);

        $users = array();

        if ($result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {
                $users[] = $row;
            }
        }

        return $users;
    }


    public function getUserById($userId) {
        // Sanitize the input to prevent SQL injection
        $userId = $this->conn->real_escape_string($userId);
    
        $query = "SELECT * FROM usuario WHERE id = $userId";
        $result = $this->conn->query($query);

        $users = array();

        if ($result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {
                $users[] = $row;
            }
        }

        return $users;
    }
    








    public function addUser($nombre,$apellido,$sexo) {

        $nombre = $this->conn->real_escape_string($nombre);
        $apellido = $this->conn->real_escape_string($apellido);

        $sexo = $this->conn->real_escape_string($sexo);



        $query = "INSERT INTO usuario (nombre,apellido,sexo) VALUES ('$nombre','$apellido','$sexo')";

        $this->conn->query($query);

    }

 






    public function deleteUser($userId) {
        $userId = $this->conn->real_escape_string($userId);

        $query = "DELETE FROM usuario WHERE id = '$userId'";
        $this->conn->query($query);
    }





    public function updateUser($userId, $userName, $userApellido) {
        // Asegúrate de validar y escapar los datos para prevenir inyecciones SQL
        $userName = mysqli_real_escape_string($this->conn, $userName);
        $userApellido = mysqli_real_escape_string($this->conn, $userApellido);

        $query = "UPDATE usuario SET nombre='$userName', apellido='$userApellido' WHERE id=$userId";
        $result = mysqli_query($this->conn, $query);

        return $result;
    }





}

#$prueba= new UserModel();



