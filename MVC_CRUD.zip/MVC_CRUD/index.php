<?php




require_once('controller/UserController.php');




$userController = new UserController();




// Enrutamiento simple basado en la URL
if (isset($_GET['action'])) {
    $action = $_GET['action'];

    switch ($action) {
        case 'add':
            $userController->add();
            break;
            case 'delete':
                $userController->delete();
                break;

                case 'update':
                    $userController->update();
                    break;

                    case 'filter':
                        // Verifica si se recibió un ID de usuario
                        if (isset($_POST['userId'])) {
                            // Llama al controlador para buscar el usuario por ID
                            $userId = $_POST['userId'];
                            $userController->getUserById($userId);
                        } else {
                            echo "Error: No se proporcionó un ID de usuario.";
                        }
                        break;
                   

            default:
                $userController->index();
                break;
    }
} else {
    $userController->index();
}
