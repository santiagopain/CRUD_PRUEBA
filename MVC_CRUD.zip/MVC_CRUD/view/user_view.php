<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User List</title>






    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js" integrity="sha384-IQsoLXl5PILFhosVNubq5LC7Qb9DXgDA9i+tQ8Zj3iwWAwPtgFTxbJ8NT4GN1R8p" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.min.js" integrity="sha384-cVKIPhGWiC2Al4u+LWgxfKTRIcfu0JTxR+EQDz/bgldoEyl4H0zUF0QKbrJ0EcQF" crossorigin="anonymous"></script>





<!-- Agrega jQuery antes de tu script para que funcione el script y que carguen los valroes en el formulario -->
<script src="https://code.jquery.com/jquery-3.6.4.min.js"></script>
 




</head>





<body>



 
<div class="container mt-5">

<form method="post" action="index.php?action=filter">

    <label for="userId">Filtrar por ID:</label>
    <input type="text" name="userId" required>

    <input type="submit" value="Buscar">

</form>
</div>

<div class="container mt-5">
<h2>Agregar</h2>


<form method="post" action="index.php?action=add">

    <label for="nombre">Nombre:</label>
    <input type="text" name="nombre" required>

    <label for="apellido">apellido:</label>
    <input type="text" name="apellido" required>

    <label for="sexo">sexo:</label>
    <input type="text" name="sexo" required>


 
    <input type="submit" value="Add User">


</form>



</div>
 
    <div class="container mt-5">
    <h1>Lista de usuarios</h1>
    <table class="table table-dark table-hover">
        
    <tr>
            <th>ID</th>
            <th>Name</th>
            <th>Apellido</th>
            <th>Sexo </th>
            <th> </th>
            <th> </th>


        </tr>
        <?php foreach ($users as $user): ?>
            <tr>
                <td><?= $user['id'] ?></td>
                <td><?= $user['nombre'] ?></td>
                <td><?= $user['apellido'] ?></td>
                <td><?= $user['sexo'] ?></td>

                <td>

                <form method="post" action="index.php?action=delete">
                    <input type="hidden" name="userId" value="<?= $user['id'] ?>">
                    <button type="submit" class="btn btn-danger">Eliminar</button>
                </form>

                </td>


<!-- Agrega un nuevo botón de editar -->
<td>

    <button type="button" class="btn btn-warning" data-bs-toggle="modal" data-bs-target="#editModal" data-userid="<?= $user['id'] ?>" data-username="<?= $user['nombre'] ?>" data-userapellido="<?= $user['apellido'] ?>">
        Editar
    </button>

</td>



               
            </tr>
        <?php endforeach; ?>
    </table>




    <div class="modal fade" id="editModal" tabindex="-1" aria-labelledby="editModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="editModalLabel">Editar Usuario</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>

            <div class="modal-body">



                <form method="post" action="index.php?action=update">
                 
                    <input type="hidden" id="editUserId" name="userId" value="">


                    <div class="mb-3">
                        <label for="editUserName" class="form-label">Nombre:</label>
                        <input type="text" class="form-control" id="editUserName" name="userName" required>
                    </div>


                    <div class="mb-3">
                        <label for="editUserApellido" class="form-label">Apellido:</label>
                        <input type="text" class="form-control" id="editUserApellido" name="userApellido" required>
                    </div>


                    <!-- Agrega otros campos del formulario según tus necesidades -->
                    <button type="submit" class="btn btn-primary">Guardar cambios</button>
                </form>


            </div>


        </div>
    </div>
</div>




<script>
    $('#editModal').on('show.bs.modal', function (event) {
        var button = $(event.relatedTarget);
        var userId = button.data('userid');
        var userName = button.data('username');
        var userApellido = button.data('userapellido');


        
    //alert(""+userId);

        var modal = $(this);
        modal.find('#editUserId').val(userId);
        modal.find('#editUserName').val(userName);
        modal.find('#editUserApellido').val(userApellido);
        // Actualiza otros campos del formulario según tus necesidades

    });
</script>





</body>
</html>
