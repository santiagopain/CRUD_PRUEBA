<?php
require_once('model/UserModel.php');

class UserController {




    public function index() {


        $userModel = new UserModel();
        $users = $userModel->getAllUsers();

        require_once('view/user_view.php');
    }
 



    public function getUserById($userId) {
        $userModel = new UserModel();
        // Llama al método de la clase de la base de datos para obtener el usuario por ID
        $users = $userModel->getUserById($userId);

        // Verifica si se encontró el usuario
        if ($users) {
            // Muestra o utiliza los datos del usuario como desees
            require_once('view/user_view.php');
        
        
        } else {
            // Maneja el caso en el que no se encuentra el usuario
            require_once('view/user_view.php');
        
        }
    }




    public function add() {

        if ($_SERVER['REQUEST_METHOD'] == 'POST') {

            $userModel = new UserModel();
            
            // Asegúrate de que los datos del formulario estén presentes y no estén vacíos
            if (isset($_POST['nombre']) && !empty($_POST['apellido'])) {

                $nombre = $_POST['nombre'];
                $apellido = $_POST['apellido'];

                $sexo = $_POST['sexo'];




                // Llama al método para agregar el usuario
                $userModel->addUser($nombre,$apellido,$sexo);

                // Redirecciona después de agregar el usuario
                header('Location: index.php');

                exit();

            } else {
                // Maneja el caso en el que el nombre no esté presente o esté vacío
                echo "Error: El nombre no puede estar vacío.";
            }
        }
    }




 
    public function delete() {
        if ($_SERVER['REQUEST_METHOD'] == 'POST') {
            $userModel = new UserModel();
    
            // Asegúrate de que el ID del usuario a eliminar esté presente y no esté vacío
            if (isset($_POST['userId']) && !empty($_POST['userId'])) {
                $userId = $_POST['userId'];
    
                // Llama al método para eliminar el usuario
                $userModel->deleteUser($userId);
    
                // Redirecciona después de eliminar el usuario
                header('Location: index.php');
                exit();
            } else {
                // Maneja el caso en el que el ID del usuario no esté presente o esté vacío
                echo "Error: El ID del usuario no puede estar vacío.";
            }
        }
    }
    

    public function update() {
        if ($_SERVER['REQUEST_METHOD'] == 'POST') {
            $userModel = new UserModel();
    
            // Asegúrate de que el ID del usuario a actualizar esté presente y no esté vacío
            if (isset($_POST['userId']) && !empty($_POST['userId'])) {
                $userId = $_POST['userId'];
    
                // Asegúrate de que los campos necesarios estén presentes y no estén vacíos
                if (isset($_POST['userName']) && isset($_POST['userApellido']) &&
                    !empty($_POST['userName']) && !empty($_POST['userApellido'])) {
    
                    $userName = $_POST['userName'];
                    $userApellido = $_POST['userApellido'];
    
                    // Llama al método para actualizar el usuario
                    $userModel->updateUser($userId, $userName, $userApellido);
    
                    // Redirecciona después de actualizar el usuario
                    header('Location: index.php');
                    exit();
                } else {
                    // Maneja el caso en el que los campos necesarios no estén presentes o estén vacíos
                    echo "Error: Nombre y Apellido no pueden estar vacíos.";
                }
            } else {
                // Maneja el caso en el que el ID del usuario no esté presente o esté vacío
                echo "Error: El ID del usuario no puede estar vacío.";
            }
        }
    }
    




}
